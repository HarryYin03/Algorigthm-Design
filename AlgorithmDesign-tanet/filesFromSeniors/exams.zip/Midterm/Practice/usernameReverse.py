fname = input("Input your First Name: ")
lname = input("Input your Last Name: ")
print("Hello " + lname + " " + fname)
