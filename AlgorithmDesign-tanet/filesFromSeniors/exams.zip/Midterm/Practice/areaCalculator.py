import math
radius = float(input())
print("r = " + str(radius))
print(math.pi * math.pow(radius, 2))