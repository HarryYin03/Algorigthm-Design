exam_st_date = (11, 12, 2014)
print("The examination will start from: %i / %i / %i" %exam_st_date)