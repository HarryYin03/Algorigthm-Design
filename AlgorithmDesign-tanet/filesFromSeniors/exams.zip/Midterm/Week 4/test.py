memo = [[-1] * (8+1) for i in range(5+1)]

print(memo)