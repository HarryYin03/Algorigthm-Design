total = 0
# for i in range(N):
#     result = l[0][i] + l[1][i]
#     if result > P:
#         extra = (result - P) * E
#         total += extra
# print(total)